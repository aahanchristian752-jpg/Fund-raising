import os
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

PRICES = {"biryani": 5.00, "samosa": 1.00}
TARGET = 500.00

DATABASE_URL = os.environ.get("DATABASE_URL")
if DATABASE_URL and DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

if DATABASE_URL:
    import psycopg
    from psycopg.rows import dict_row

    def db():
        return psycopg.connect(DATABASE_URL, row_factory=dict_row)

    def init_db():
        with db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sales (
                    id BIGSERIAL PRIMARY KEY,
                    food TEXT NOT NULL CHECK (food IN ('biryani', 'samosa')),
                    price NUMERIC(10,2) NOT NULL CHECK (price > 0),
                    created_at TIMESTAMPTZ NOT NULL
                )
            """)
else:
    import sqlite3
    DB_PATH = Path(__file__).resolve().parent / "fundraiser.db"

    def db():
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db():
        with db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    food TEXT NOT NULL CHECK(food IN ('biryani', 'samosa')),
                    price REAL NOT NULL CHECK(price > 0),
                    created_at TEXT NOT NULL
                )
            """)

def totals():
    with db() as conn:
        rows = conn.execute("""
            SELECT food, COUNT(*) AS quantity, COALESCE(SUM(price), 0) AS amount
            FROM sales GROUP BY food
        """).fetchall()

    result = {"biryani": 0, "samosa": 0, "raised": 0.0}
    for row in rows:
        result[row["food"]] = int(row["quantity"])
        result["raised"] += float(row["amount"])

    result["items"] = result["biryani"] + result["samosa"]
    result["remaining"] = max(0.0, TARGET - result["raised"])
    result["percent"] = min(100.0, result["raised"] / TARGET * 100 if TARGET else 0)
    return result

def valid_food(food):
    return food in PRICES

@app.get("/")
def index():
    return render_template("index.html", prices=PRICES, target=TARGET)

@app.get("/health")
def health():
    return jsonify({"status": "ok"})

@app.get("/api/totals")
def api_totals():
    return jsonify(totals())

@app.post("/api/sale")
def api_sale():
    data = request.get_json(silent=True) or {}
    food = data.get("food")
    try:
        quantity = int(data.get("quantity", 1))
    except (TypeError, ValueError):
        return jsonify({"error": "Quantity must be a whole number."}), 400

    if not valid_food(food) or not 1 <= quantity <= 100:
        return jsonify({"error": "Invalid food item or quantity."}), 400

    now = datetime.now(timezone.utc)
    price = PRICES[food]

    with db() as conn:
        for _ in range(quantity):
            conn.execute(
                "INSERT INTO sales(food, price, created_at) VALUES (%s, %s, %s)"
                if DATABASE_URL else
                "INSERT INTO sales(food, price, created_at) VALUES (?, ?, ?)",
                (food, price, now)
            )
    return jsonify(totals())

@app.post("/api/undo")
def api_undo():
    data = request.get_json(silent=True) or {}
    food = data.get("food")
    if not valid_food(food):
        return jsonify({"error": "Invalid food item."}), 400

    with db() as conn:
        row = conn.execute(
            "SELECT id FROM sales WHERE food = %s ORDER BY id DESC LIMIT 1"
            if DATABASE_URL else
            "SELECT id FROM sales WHERE food = ? ORDER BY id DESC LIMIT 1",
            (food,)
        ).fetchone()
        if row:
            conn.execute(
                "DELETE FROM sales WHERE id = %s" if DATABASE_URL else "DELETE FROM sales WHERE id = ?",
                (row["id"],)
            )
    return jsonify(totals())

@app.post("/api/reset")
def api_reset():
    with db() as conn:
        conn.execute("DELETE FROM sales")
    return jsonify(totals())

@app.get("/api/history")
def api_history():
    with db() as conn:
        rows = conn.execute("""
            SELECT id, food, price, created_at
            FROM sales ORDER BY id DESC LIMIT 100
        """).fetchall()
    return jsonify([
        {**dict(row), "created_at": row["created_at"].isoformat() if hasattr(row["created_at"], "isoformat") else row["created_at"]}
        for row in rows
    ])

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
