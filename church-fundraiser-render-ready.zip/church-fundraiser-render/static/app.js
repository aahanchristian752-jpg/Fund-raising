const state = { busy: false };

const $ = (id) => document.getElementById(id);

function money(value) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency", currency: "GBP"
  }).format(Number(value || 0));
}

function animateValue(el, value) {
  el.classList.remove("flash");
  void el.offsetWidth;
  el.classList.add("flash");
  el.textContent = value;
}

function renderTotals(data) {
  animateValue($("biryaniTotal"), data.biryani);
  animateValue($("samosaTotal"), data.samosa);
  animateValue($("biryaniCardCount"), data.biryani);
  animateValue($("samosaCardCount"), data.samosa);
  $("raised").textContent = money(data.raised);
  $("remaining").textContent = money(data.remaining);
  $("items").textContent = `${data.items} item${data.items === 1 ? "" : "s"}`;
  $("percent").textContent = Math.round(data.percent);
  $("progressAmount").textContent = `${money(data.raised)} / £500`;
  $("progressBar").style.width = `${data.percent}%`;
}

function setStatus(message) {
  $("status").textContent = message;
  if (message) setTimeout(() => $("status").textContent = "", 1800);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    cache: "no-store"
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

async function recordSale(food, quantity) {
  if (state.busy) return;
  state.busy = true;
  try {
    const data = await api("/api/sale", {
      method: "POST",
      body: JSON.stringify({ food, quantity })
    });
    renderTotals(data);
    setStatus(`${quantity} ${food} sale${quantity > 1 ? "s" : ""} recorded`);
  } catch (error) {
    setStatus(error.message);
  } finally {
    state.busy = false;
  }
}

async function undo(food) {
  if (state.busy) return;
  state.busy = true;
  try {
    const data = await api("/api/undo", {
      method: "POST", body: JSON.stringify({ food })
    });
    renderTotals(data);
    await loadHistory();
    setStatus(`Most recent ${food} sale undone`);
  } catch (error) {
    setStatus(error.message);
  } finally {
    state.busy = false;
  }
}

async function loadHistory() {
  const rows = await api("/api/history");
  const list = $("historyList");
  if (!rows.length) {
    list.innerHTML = `<div class="history-row"><span>No sales recorded yet.</span></div>`;
    return;
  }
  list.innerHTML = rows.map(row => {
    const name = row.food === "biryani" ? "🍛 Biryani" : "🥟 Samosa";
    const date = new Date(row.created_at).toLocaleString("en-GB", {
      dateStyle: "short", timeStyle: "short"
    });
    return `<div class="history-row">
      <div><strong>${name}</strong><span>${date}</span></div>
      <strong>${money(row.price)}</strong>
    </div>`;
  }).join("");
}

async function refresh() {
  try {
    const data = await api("/api/totals");
    renderTotals(data);
    await loadHistory();
  } catch (error) {
    setStatus("Could not connect to the server.");
  }
}

document.querySelectorAll(".tab").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab, .tab-panel").forEach(el => el.classList.remove("active"));
    button.classList.add("active");
    $(button.dataset.tab).classList.add("active");
    if (button.dataset.tab === "history") loadHistory();
  });
});

document.querySelectorAll(".sell-button").forEach(button => {
  button.addEventListener("click", () => recordSale(button.dataset.food, Number(button.dataset.qty)));
});

document.querySelectorAll(".add-five").forEach(button => {
  button.addEventListener("click", () => recordSale(button.dataset.food, 5));
});

document.querySelectorAll(".undo-btn").forEach(button => {
  button.addEventListener("click", () => undo(button.dataset.food));
});

$("clearAll").addEventListener("click", async () => {
  if (!confirm("Clear every recorded sale? This cannot be undone.")) return;
  if (state.busy) return;
  state.busy = true;
  try {
    const data = await api("/api/reset", { method: "POST", body: "{}" });
    renderTotals(data);
    await loadHistory();
    setStatus("All sales cleared");
  } catch (error) {
    setStatus(error.message);
  } finally {
    state.busy = false;
  }
});

refresh();
