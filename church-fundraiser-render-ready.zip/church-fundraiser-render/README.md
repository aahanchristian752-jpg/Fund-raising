# Church Food Fundraiser — Render-ready

This version is prepared for deployment on Render.

## What changed for Render

- Uses Gunicorn in production.
- Uses Render Postgres when `DATABASE_URL` is present.
- Keeps SQLite as a local fallback for testing.
- Includes a `/health` endpoint for Render health checks.
- Includes `render.yaml` so the web service and Postgres database can be configured together.
- Pins the project to Python 3.13 through `.python-version`.

Render's normal Flask setup uses:
- Build: `pip install -r requirements.txt`
- Start: `gunicorn app:app`

## Deploy with Render

### Option A — Blueprint (recommended)

1. Put this project into a GitHub repository.
2. Sign in to Render.
3. Choose **New → Blueprint**.
4. Select the GitHub repository.
5. Render reads `render.yaml`.
6. Review the services and deploy.

The Blueprint creates:
- a Python web service named `church-food-fundraiser`
- a Postgres database named `church-fundraiser-db`
- a `DATABASE_URL` connection for the web service

After deployment, Render gives the web service an `onrender.com` HTTPS URL.

### Option B — Manual Web Service

If you do not use the Blueprint:

Build command:
    pip install -r requirements.txt

Start command:
    gunicorn app:app

Then create a Render Postgres database and set the web service environment variable:
    DATABASE_URL

Use the database's internal connection string.

## Important database note

Do not rely on the SQLite file for the public Render deployment. Render services have ephemeral filesystems by default, so local SQLite changes can disappear after redeploys or restarts.

This project therefore switches to Postgres automatically when `DATABASE_URL` exists.

## Local testing

Install packages:
    python -m pip install -r requirements.txt

Run:
    python app.py

Open:
    http://127.0.0.1:5000

## Security before public fundraising use

This version validates food and quantity on the server and does not trust browser-supplied prices.

Before giving the public/admin URL to many people, add authentication/authorisation for administrative actions such as clearing all sales. HTTPS is handled by Render for the deployed service.

## HTTPS

Render provides the deployed service through an HTTPS `onrender.com` URL. You do not need to create your own TLS certificate for that default URL.
